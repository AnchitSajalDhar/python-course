# -*- coding: utf-8 -*-
"""
Created on Fri Aug 28 19:08:47 2020

@author: Hp
"""


str1=input("\n enter the number")
list1=list(str1.split())

del list1[0]
del list1[4]
del list1[5]