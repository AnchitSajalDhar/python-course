# -*- coding: utf-8 -*-
"""
Created on Fri Aug 28 19:52:10 2020

@author: Hp
"""

nums = set([1,1,2,3,3,3,4,4])
print(len(nums))
#the output is 4 for the code segment 1

d = {"john":40, "peter":45}
print(list(d.keys()))
#keys are printed 