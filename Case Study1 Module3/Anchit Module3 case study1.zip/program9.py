# -*- coding: utf-8 -*-
"""
Created on Thu Sep  3 13:17:43 2020

@author: Hp
"""

row_num = int(input("Input number of rows: "))
col_num = int(input("Input number of columns: "))
multi_list = [[0 for col in range(col_num)] for row in range(row_num)]

for row in range(row_num):
    for col in range(col_num):
        multi_list[row][col]= row*col

print(multi_list)
