# -*- coding: utf-8 -*-
"""
Created on Sat Sep  5 19:14:39 2020

@author: Hp
"""

import math

print(math.fsum(range(10)))

numbers = [1,2,3,4,5,1,4,5] 
  
 
Sum = sum(numbers) 
print(Sum) 