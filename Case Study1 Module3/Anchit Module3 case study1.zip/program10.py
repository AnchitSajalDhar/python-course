# -*- coding: utf-8 -*-
"""
Created on Thu Sep  3 13:23:27 2020

@author: Hp
"""

str1=input("enter the sequence of words with comma seperation")
list1=str1.split(",")
list1.sort()

print(list1)